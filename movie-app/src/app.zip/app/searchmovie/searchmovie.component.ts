import { Component, OnInit } from '@angular/core';
import { MovieserviceService } from '../movieservice.service';

@Component({
  selector: 'app-searchmovie',
  templateUrl: './searchmovie.component.html',
  styleUrls: ['./searchmovie.component.css']
})
export class SearchmovieComponent implements OnInit {

  errormsg = "";
  heroes = "";
  movies = [];

  constructor(private movieserviceService: MovieserviceService) { }

  ngOnInit() {

  }
  display(newHero) {
  this.heroes = newHero;
  console.log(this.heroes);
    this.movieserviceService.getMoviesByName(this.heroes).subscribe(
      (data) => this.movies = data['results'],
      (error) => this.errormsg = error
    );
  }

}
