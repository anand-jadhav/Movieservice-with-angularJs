export interface Movie {
    id:string,
    movieTitle: string,
    posterUrl: string,
    rating:number,
    yearOfRelease: number,
    comments:string
}
