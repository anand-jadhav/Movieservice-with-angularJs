import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-moviedetail',
  templateUrl: './moviedetail.component.html',
  styleUrls: ['./moviedetail.component.css']
})
export class MoviedetailComponent implements OnInit {
  @Input('search') movies;
  constructor() { }

  ngOnInit() {
  }
  
}
